var atm = {
	balance: 1000,
	withdrawal: 0,
	deposit: 0,
	maxDeposit: 20000
}, 
amount, 
showNumbers = document.getElementById('show-numbers'),
okBtn = document.getElementById('ok-btn'),
clearBtn = document.getElementById('clear-btn'); 

okBtn.addEventListener('click', function(e) {
	 
})

for(var i = 9; i >= 0; i--) {
	var keyboard = document.getElementById('keyboard');
	var btn = document.createElement('div');
	btn.classList.add('atm-btn');
	btn.innerHTML = i;
	keyboard.appendChild(btn);
	btn.addEventListener('click', function(e) {
		if (amount == undefined) {
			amount = e.target.innerHTML;
		}
		else {
			amount += e.target.innerHTML;
		}
		showNumbers.innerHTML = amount;
	})
}

